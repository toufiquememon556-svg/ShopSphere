
import { GoogleGenAI, Type } from "@google/genai";
import { PRODUCTS } from "../constants";

const apiKey = process.env.API_KEY || "";
const ai = new GoogleGenAI({ apiKey });

export async function getShoppingAdvice(userPrompt: string, history: {role: 'user' | 'model', parts: {text: string}[]}[]) {
  const productsContext = JSON.stringify(PRODUCTS.map(p => ({
    id: p.id,
    name: p.name,
    price: p.price,
    category: p.category,
    description: p.description
  })));

  const systemInstruction = `
    You are a luxury personal shopping assistant for LuxeCommerce AI. 
    Your goal is to help users find the best products from our catalog.
    Our current catalog is: ${productsContext}
    
    Guidelines:
    1. Be polite, sophisticated, and helpful.
    2. Recommend products by name and explain why they fit the user's needs.
    3. If a user asks for something we don't have, politely suggest the closest alternative.
    4. Keep responses concise but engaging.
    5. When recommending, mention the price and features.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: [
        ...history,
        { role: 'user', parts: [{ text: userPrompt }] }
      ],
      config: {
        systemInstruction,
        temperature: 0.7,
        topP: 0.95,
      }
    });

    return response.text;
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "I'm having a brief moment of reflection. How can I assist you with your shopping today?";
  }
}

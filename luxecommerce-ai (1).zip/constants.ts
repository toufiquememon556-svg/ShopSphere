
import { Product } from './types';

export const PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'Zenith Wireless Headphones',
    price: 299,
    description: 'Active noise cancelling with 40-hour battery life and premium leather cushions.',
    category: 'Electronics',
    image: 'https://picsum.photos/seed/headphones/600/600',
    rating: 4.8
  },
  {
    id: '2',
    name: 'Urban Explorer Backpack',
    price: 85,
    description: 'Water-resistant, laptop-ready, and ergonomically designed for daily commuters.',
    category: 'Apparel',
    image: 'https://picsum.photos/seed/backpack/600/600',
    rating: 4.5
  },
  {
    id: '3',
    name: 'Ethereal Silk Scarf',
    price: 120,
    description: 'Hand-woven 100% pure silk scarf with limited edition floral patterns.',
    category: 'Apparel',
    image: 'https://picsum.photos/seed/scarf/600/600',
    rating: 4.9
  },
  {
    id: '4',
    name: 'Lumina Smart Lamp',
    price: 150,
    description: 'Adjustable color temperature and brightness controlled via mobile app or voice.',
    category: 'Home',
    image: 'https://picsum.photos/seed/lamp/600/600',
    rating: 4.7
  },
  {
    id: '5',
    name: 'Velvet Matte Lipstick',
    price: 35,
    description: 'Long-lasting, smudge-proof formula with natural organic pigments.',
    category: 'Beauty',
    image: 'https://picsum.photos/seed/lipstick/600/600',
    rating: 4.6
  },
  {
    id: '6',
    name: 'Titanium Chef Knife',
    price: 180,
    description: 'Professional grade 8-inch blade forged from high-carbon titanium steel.',
    category: 'Home',
    image: 'https://picsum.photos/seed/knife/600/600',
    rating: 4.9
  },
  {
    id: '7',
    name: 'Ocular VR Headset',
    price: 499,
    description: 'Immersive 4K resolution per eye with advanced spatial tracking.',
    category: 'Electronics',
    image: 'https://picsum.photos/seed/vr/600/600',
    rating: 4.4
  },
  {
    id: '8',
    name: 'Nordic Wool Sweater',
    price: 110,
    description: 'Authentic merino wool blend with traditional geometric patterns.',
    category: 'Apparel',
    image: 'https://picsum.photos/seed/sweater/600/600',
    rating: 4.7
  }
];

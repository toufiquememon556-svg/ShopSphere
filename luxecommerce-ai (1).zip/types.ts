
export interface Product {
  id: string;
  name: string;
  price: number;
  description: string;
  category: 'Electronics' | 'Apparel' | 'Home' | 'Beauty';
  image: string;
  rating: number;
}

export interface CartItem extends Product {
  quantity: number;
}

export interface ChatMessage {
  role: 'user' | 'model';
  content: string;
}
